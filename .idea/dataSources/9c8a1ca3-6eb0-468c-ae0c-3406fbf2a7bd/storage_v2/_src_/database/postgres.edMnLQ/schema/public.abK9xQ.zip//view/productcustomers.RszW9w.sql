create view productcustomers as
SELECT customers.cust_name,
       customers.cust_contact,
       orderitems.prod_id
FROM customers,
     orders,
     orderitems
WHERE ((customers.cust_id = orders.cust_id) AND (orders.order_num = orderitems.order_num));

alter table productcustomers
  owner to postgres;

